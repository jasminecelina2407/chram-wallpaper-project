# Evil Eye Charm — Swinging Wallpaper

A single-page HTML/CSS project that hangs an animated evil eye charm at the top of a soft navy-violet wallpaper, swinging gently like it's dangling in front of the screen.

## Run it locally

No build step needed — it's plain HTML/CSS.

1. Download or clone this folder.
2. Open `index.html` directly in your browser (double-click it), **or** serve it locally for the best experience:
   - VS Code: install the "Live Server" extension, right-click `index.html`, choose **Open with Live Server**.
   - Or with Python installed: run `python3 -m http.server` in this folder, then visit `http://localhost:8000`.

## Files

- `index.html` — page structure
- `style.css` — background, charm positioning, and the swing animation
- `assets/wallpaper-bg.png` — the navy-violet backdrop
- `assets/evil-eye-charm.png` — the transparent charm cutout
